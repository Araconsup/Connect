import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # room_name: from URL route kwargs
        self.room_name = self.scope['url_route']['kwargs'].get('room_name')
        self.room_group_name = f'chat_{self.room_name}'

        # Add to room group
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)

        # If authenticated, add to personal user group for private messages
        user = self.scope.get('user')
        if user and getattr(user, 'is_authenticated', False):
            self.user_group_name = f'user_{user.username}'
            await self.channel_layer.group_add(self.user_group_name, self.channel_name)
        else:
            self.user_group_name = None

        await self.accept()

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)
        if getattr(self, 'user_group_name', None):
            await self.channel_layer.group_discard(self.user_group_name, self.channel_name)

    async def receive(self, text_data=None, bytes_data=None):
        try:
            data = json.loads(text_data)
        except Exception:
            return

        # Data may contain: { message, username } for public; or { private: True, to, from, message }
        if data.get('private'):
            # send to recipient's personal group
            to_username = data.get('to')
            from_username = data.get('from') or (self.scope.get('user').username if self.scope.get('user') else 'Anonymous')
            message = data.get('message')
            if not to_username or not message:
                return
            target_group = f'user_{to_username}'
            await self.channel_layer.group_send(
                target_group,
                {
                    'type': 'chat.message',
                    'message': message,
                    'username': from_username,
                    'private': True,
                }
            )
            # also echo back to sender
            await self.channel_layer.group_send(
                f'user_{from_username}',
                {
                    'type': 'chat.message',
                    'message': message,
                    'username': from_username,
                    'private': True,
                }
            )
        else:
            # broadcast to room
            message = data.get('message')
            username = data.get('username') or (self.scope.get('user').username if self.scope.get('user') else 'Anonymous')
            if message:
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat.message',
                        'message': message,
                        'username': username,
                        'private': False,
                    }
                )

    async def chat_message(self, event):
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'message': event.get('message'),
            'username': event.get('username'),
            'private': event.get('private', False),
        }))

