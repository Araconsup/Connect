from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.contrib.contenttypes.models import ContentType

class User(AbstractUser):
    # Add extra fields here if needed (e.g., profile_pic, bio)
    bio = models.TextField(blank=True, null=True)
    profile_pic = models.ImageField(upload_to='profile_pics/', blank=True, null=True)

    def __str__(self):
        return self.username


# Main post model (can have multiple media files)
class Post(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')
    caption = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    # Generic relations for likes/comments
    likes = GenericRelation('Like', related_query_name='post')
    comments = GenericRelation('Comment', related_query_name='post')

    def __str__(self):
        return f"{self.user.username} - {self.caption[:20]}"

# Media files for posts
class MediaFile(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='media_files')
    file = models.FileField(upload_to='media_files/')

    def __str__(self):
        return f"Media for {self.post.id}"

# Reels (videos only)
class Reel(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reels')
    video = models.FileField(upload_to='reels/')
    caption = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Reel by {self.user.username}"

    likes = GenericRelation('Like', related_query_name='reel')
    comments = GenericRelation('Comment', related_query_name='reel')

# Connects (tweet-like posts)
class Connect(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='connects')
    text = models.CharField(max_length=280)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Connect by {self.user.username}: {self.text[:20]}"

    likes = GenericRelation('Like', related_query_name='connect')
    comments = GenericRelation('Comment', related_query_name='connect')

# Music uploads
class Music(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='musics')
    title = models.CharField(max_length=255)
    artist = models.CharField(max_length=255, blank=True, null=True)
    cover = models.ImageField(upload_to='music_covers/', blank=True, null=True)
    file = models.FileField(upload_to='music/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        artist_part = f" by {self.artist}" if self.artist else ''
        return f"Music: {self.title}{artist_part} (uploaded by {self.user.username})"

    likes = GenericRelation('Like', related_query_name='music')
    comments = GenericRelation('Comment', related_query_name='music')


# Generic Like model to support liking multiple content types
class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='likes')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'content_type', 'object_id')
        ordering = ['-created_at']


# Generic Comment model to support commenting on multiple content types
class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.text[:20]}"
