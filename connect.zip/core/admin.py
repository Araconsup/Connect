from django.contrib import admin
from .models import User

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
	list_display = ('username', 'email', 'is_staff', 'is_active')

from .models import Post, MediaFile, Reel, Connect, Music

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
	list_display = ('user', 'caption', 'created_at')

@admin.register(MediaFile)
class MediaFileAdmin(admin.ModelAdmin):
	list_display = ('post', 'file')

@admin.register(Reel)
class ReelAdmin(admin.ModelAdmin):
	list_display = ('user', 'caption', 'created_at')

@admin.register(Connect)
class ConnectAdmin(admin.ModelAdmin):
	list_display = ('user', 'text', 'created_at')

@admin.register(Music)
class MusicAdmin(admin.ModelAdmin):
	list_display = ('user', 'title', 'created_at')
