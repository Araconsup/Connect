import { getChat, setChat } from './store'

const DEFAULT_WS_BASE = (typeof window !== 'undefined' && window.location)
  ? `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.hostname}:8000/ws`
  : 'ws://127.0.0.1:8000/ws'
const WS_BASE = import.meta.env.VITE_WS_BASE || DEFAULT_WS_BASE

function eventKey(room) {
  return `connect-chat-message:${room}`
}

function makeLocalSocket(room, onMessage, onOpen, handlers = {}) {
  const username = localStorage.getItem('username') || 'guest'
  let closedByUser = false
  let open = false

  const emit = (msg) => {
    if (closedByUser) return
    const next = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      user: { username, avatar: '', name: username },
      text: msg.message || msg.text || '',
      private: Boolean(msg.private),
      created_at: new Date().toISOString(),
      mine: true,
    }
    const current = getChat(room)
    const updated = [...current, next]
    setChat(room, updated)
    if (handlers.onMessage) handlers.onMessage(next)
    window.dispatchEvent(new CustomEvent(eventKey(room), { detail: next }))
  }

  const listener = (e) => {
    const payload = e.detail
    if (!payload || closedByUser) return
    onMessage?.({
      username: payload.user?.username || 'guest',
      message: payload.text || '',
      private: payload.private,
      avatar: payload.user?.avatar || '',
      created_at: payload.created_at,
    })
  }

  window.addEventListener(eventKey(room), listener)
  queueMicrotask(() => {
    if (closedByUser) return
    open = true
    onOpen?.()
  })

  return {
    get readyState() { return open ? WebSocket.OPEN : WebSocket.CONNECTING },
    send(payload) {
      if (closedByUser) return
      try {
        const parsed = typeof payload === 'string' ? JSON.parse(payload) : payload
        emit(parsed || {})
      } catch {
        emit({ message: String(payload || '') })
      }
    },
    close() {
      closedByUser = true
      window.removeEventListener(eventKey(room), listener)
      handlers.onClose?.()
    },
  }
}

export function connectToChat(onMessage, onOpen, room = 'public', handlers = {}) {
  const base = WS_BASE.replace(/\/+$/, '')
  const token = localStorage.getItem('token') || ''
  const raw = token && String(token).startsWith('Bearer ') ? String(token).slice(7) : token
  const hasToken = raw && raw.includes('.') && !String(raw).startsWith('local-')
  let wsUrl = `${base}/chat/${encodeURIComponent(room)}/`
  if (hasToken) wsUrl += `?token=${encodeURIComponent(raw)}`

  try {
    const socket = new WebSocket(wsUrl)
    socket.onopen = () => onOpen?.()
    socket.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data)
        onMessage?.(payload)
      } catch {
        onMessage?.({ message: event.data })
      }
    }
    socket.onerror = () => handlers.onError?.()
    socket.onclose = () => handlers.onClose?.()
    return socket
  } catch {
    return makeLocalSocket(room, onMessage, onOpen, handlers)
  }
}
