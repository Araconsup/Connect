import React, { useEffect, useMemo, useRef, useState } from 'react'
import ProfileModal from '../components/ProfileModal'
import Icon from '../components/Icon'
import { avatarUrl } from '../services/assets'
import { connectToChat } from '../services/ws'
import { getProfile, getLocalSession } from '../services/api'
import { getChat, setChat } from '../services/store'

export default function Chat() {
  const [messages, setMessages] = useState(() => getChat('public'))
  const [text, setText] = useState('')
  const [ws, setWs] = useState(null)
  const [profileUser, setProfileUser] = useState(null)
  const [connected, setConnected] = useState(false)
  const [error, setError] = useState('')
  const listRef = useRef(null)

  const people = useMemo(() => {
    const seen = new Map()
    messages.forEach((msg) => {
      const user = msg.user || {}
      if (!user.username) return
      seen.set(user.username, user)
    })
    return Array.from(seen.values()).slice(0, 6)
  }, [messages])

  useEffect(() => {
    const socket = connectToChat(
      () => {
        setMessages(getChat('public'))
      },
      () => {
        setConnected(true)
        setError('')
      },
      'public',
      {
        onError: () => setError('Chat connection failed.'),
        onClose: () => setConnected(false),
      }
    )
    setWs(socket)
    return () => socket && socket.close()
  }, [])

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight
    }
  }, [messages])

  const send = () => {
    if (!ws || ws.readyState !== WebSocket.OPEN || !text.trim()) return
    const username = localStorage.getItem('username')
    ws.send(JSON.stringify({ message: text, username }))
    setText('')
  }

  const openProfile = async (user) => {
    if (!user?.username) return
    try {
      const profile = await getProfile(user.username)
      setProfileUser(profile)
    } catch {
      setProfileUser(user)
    }
  }

  return (
    <div className="page-shell chat-shell page-fade-in">
      <section className="page-hero surface">
        <div className="hero-copy">
          <div className="eyebrow">Chat</div>
          <h1>Public room</h1>
          <p>Fast messages, profile popups, and a room layout that feels more like a real messenger.</p>
        </div>
        <div className="hero-note">{connected ? 'Connected' : 'Connecting…'}{error ? ` · ${error}` : ''}</div>
      </section>

      <section className="chat-layout">
        <aside className="surface chat-people">
          <div className="section-header">
            <div>
              <span className="muted-text">People</span>
              <h3>Active in room</h3>
            </div>
          </div>
          <div className="people-list">
            {people.map((person) => (
              <button key={person.username} type="button" className="person-row btn-animated" onClick={() => openProfile(person)}>
                <img src={avatarUrl(person)} alt="" className="person-avatar" />
                <div>
                  <strong>@{person.username}</strong>
                  <span>{person.mine ? 'You' : 'In the room'}</span>
                </div>
              </button>
            ))}
          </div>
        </aside>

        <div className="chat-column">
          <section className="surface chat-thread" ref={listRef} aria-live="polite" aria-label="Chat messages">
            {messages.map((m, i) => (
              <button key={i} type="button" className={`chat-row ${m.mine ? 'mine' : ''}`} onClick={() => openProfile(m.user)}>
                <img src={avatarUrl(m.user)} alt="" className="chat-avatar" />
                <div className="chat-bubble">
                  <div className="chat-row-head">
                    <strong>@{m.user?.username || 'guest'}</strong>
                    <span>{m.created_at ? new Date(m.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : ''}</span>
                  </div>
                  <p>{m.text}</p>
                </div>
              </button>
            ))}
          </section>

          <section className="surface chat-compose">
            <div className="chat-compose-row">
              <input
                className="text-input"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Write a message"
                onKeyDown={(e) => { if (e.key === 'Enter') send() }}
              />
              <button type="button" className="btn btn-primary btn-animated" onClick={send} disabled={!text.trim()}>
                <Icon name="send" size={16} />
                <span>Send</span>
              </button>
            </div>
            <p className="form-help">If the websocket is unavailable, chat falls back to local messages so the room still works.</p>
          </section>
        </div>
      </section>

      {profileUser && <ProfileModal user={profileUser} onClose={() => setProfileUser(null)} />}
    </div>
  )
}
