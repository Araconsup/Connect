import React, { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import Icon from './Icon'

const items = [
  { to: '/', icon: 'home', label: 'Home' },
  { to: '/reels', icon: 'reels', label: 'Reels' },
  { to: '/upload', icon: 'upload', label: 'Create' },
  { to: '/chat', icon: 'chat', label: 'Chat' },
  { to: '/music', icon: 'music', label: 'Music' },
]

export default function BottomNav() {
  const [username, setUsername] = useState(localStorage.getItem('username') || 'guest')

  useEffect(() => {
    const sync = () => setUsername(localStorage.getItem('username') || 'guest')
    window.addEventListener('login', sync)
    window.addEventListener('logout', sync)
    window.addEventListener('connect-session-change', sync)
    window.addEventListener('storage', sync)
    return () => {
      window.removeEventListener('login', sync)
      window.removeEventListener('logout', sync)
      window.removeEventListener('connect-session-change', sync)
      window.removeEventListener('storage', sync)
    }
  }, [])

  return (
    <nav className="bottom-nav" aria-label="Primary navigation">
      <Link to="/" className="nav-brand" aria-label="Go to home">
        <span className="nav-brand-mark"><Icon name="spark" size={18} /></span>
        <span className="nav-brand-copy">
          <strong>Connect</strong>
          <small>glossy studio</small>
        </span>
      </Link>

      <div className="nav-links">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </div>

      <Link className="nav-footer" to={`/profile/${username}`} aria-label="Open your profile">
        <span className="nav-footer-dot" />
        <div>
          <strong>@{username}</strong>
          <small>Signed in</small>
        </div>
      </Link>
    </nav>
  )
}
