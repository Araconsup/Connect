import React, { Suspense, useEffect, useState } from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import BottomNav from './components/BottomNav'
import GlobalMusicPlayer from './components/GlobalMusicPlayer'
import Notifications from './components/Notifications'
import { MusicPlayerProvider, useMusicPlayer } from './context/MusicPlayerContext'
import { setAuthFromStorage } from './services/api'

const Login = React.lazy(() => import('./pages/Login'))
const Home = React.lazy(() => import('./pages/Home'))
const Reels = React.lazy(() => import('./pages/Reels'))
const Upload = React.lazy(() => import('./pages/Upload'))
const Chat = React.lazy(() => import('./pages/Chat'))
const Profile = React.lazy(() => import('./pages/Profile'))
const Music = React.lazy(() => import('./pages/Music'))

function LoadingScreen() {
  return <div className="page-shell"><div className="surface empty-state">Loading…</div></div>
}

function AppContent() {
  const location = useLocation()
  const { currentTrack, isPlaying } = useMusicPlayer()
  const pathname = location.pathname.toLowerCase()
  const isReelsRoute = pathname.includes('/reels')
  const showGlobalPlayer =
    Boolean(currentTrack && isPlaying) &&
    location.pathname !== '/music' &&
    !isReelsRoute

  return (
    <div className={`app-shell-root ${showGlobalPlayer ? 'with-global-player' : ''} ${isReelsRoute ? 'is-reels-route' : ''}`}>
      <Notifications />
      {showGlobalPlayer && <GlobalMusicPlayer />}
      <main className={location.pathname === '/reels' ? 'app-main app-main-reels' : 'app-main'}>
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/reels" element={<Reels />} />
            <Route path="/upload" element={<Upload />} />
            <Route path="/chat" element={<Chat />} />
            <Route path="/music" element={<Music />} />
            <Route path="/profile/:username" element={<Profile />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </main>
      {location.pathname !== '/reels' && <BottomNav />}
    </div>
  )
}

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token'))

  useEffect(() => {
    const sync = () => {
      setAuthFromStorage()
      setToken(localStorage.getItem('token'))
    }

    window.addEventListener('login', sync)
    window.addEventListener('logout', sync)
    window.addEventListener('storage', sync)
    sync()

    return () => {
      window.removeEventListener('login', sync)
      window.removeEventListener('logout', sync)
      window.removeEventListener('storage', sync)
    }
  }, [])

  if (!token) {
    return (
      <Suspense fallback={<LoadingScreen />}>
        <Routes>
          <Route path="/*" element={<Login />} />
        </Routes>
      </Suspense>
    )
  }

  return (
    <MusicPlayerProvider>
      <AppContent />
    </MusicPlayerProvider>
  )
}
