import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { fullUrl } from '../services/api'

const MusicPlayerContext = createContext(null)

export function useMusicPlayer() {
  const ctx = useContext(MusicPlayerContext)
  if (!ctx) throw new Error('useMusicPlayer must be used within MusicPlayerProvider')
  return ctx
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value))
}

export function MusicPlayerProvider({ children }) {
  const audioRef = useRef(null)
  const [tracks, setTracks] = useState([])
  const [currentTrackId, setCurrentTrackId] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(0.9)
  const [muted, setMuted] = useState(false)
  const [repeat, setRepeat] = useState('off')

  const currentIndex = useMemo(() => tracks.findIndex((track) => track?.id === currentTrackId), [tracks, currentTrackId])
  const currentTrack = currentIndex >= 0 ? tracks[currentIndex] : null

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    audio.volume = muted ? 0 : volume
  }, [volume, muted])

  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    const onLoaded = () => {
      setDuration(Number.isFinite(audio.duration) ? audio.duration : 0)
      setCurrentTime(0)
    }
    const onTime = () => setCurrentTime(audio.currentTime || 0)
    const onPlay = () => setIsPlaying(true)
    const onPause = () => setIsPlaying(false)
    const onEnded = () => {
      if (repeat === 'one' && currentTrack) {
        audio.currentTime = 0
        audio.play().catch(() => {})
        return
      }
      nextTrack()
    }

    audio.addEventListener('loadedmetadata', onLoaded)
    audio.addEventListener('durationchange', onLoaded)
    audio.addEventListener('timeupdate', onTime)
    audio.addEventListener('play', onPlay)
    audio.addEventListener('pause', onPause)
    audio.addEventListener('ended', onEnded)

    return () => {
      audio.removeEventListener('loadedmetadata', onLoaded)
      audio.removeEventListener('durationchange', onLoaded)
      audio.removeEventListener('timeupdate', onTime)
      audio.removeEventListener('play', onPlay)
      audio.removeEventListener('pause', onPause)
      audio.removeEventListener('ended', onEnded)
    }
  }, [currentTrack, repeat])

  useEffect(() => {
    if (!audioRef.current) return
    if (!currentTrack?.file) {
      audioRef.current.removeAttribute('src')
      audioRef.current.load()
      setIsPlaying(false)
      setCurrentTime(0)
      setDuration(0)
      return
    }

    const audio = audioRef.current
    audio.src = fullUrl(currentTrack.file)
    audio.load()
    audio.volume = muted ? 0 : volume
    audio.play().catch(() => {
      setIsPlaying(false)
    })
  }, [currentTrackId, currentTrack?.file, muted, volume])

  const playTrack = (track) => {
    if (!track) return
    const id = track.id
    setTracks((prev) => (prev.some((item) => item?.id === id) ? prev : [...prev, track]))
    if (currentTrackId === id && audioRef.current) {
      if (audioRef.current.paused) audioRef.current.play().catch(() => {})
      else audioRef.current.pause()
      return
    }
    setCurrentTrackId(id)
  }

  const pause = () => audioRef.current?.pause()
  const play = () => audioRef.current?.play().catch(() => {})
  const togglePlay = () => {
    const audio = audioRef.current
    if (!audio) return
    if (audio.paused) play()
    else pause()
  }

  const seekTo = (nextTime) => {
    const audio = audioRef.current
    if (!audio || !Number.isFinite(audio.duration) || audio.duration <= 0) return
    const value = clamp(nextTime, 0, audio.duration)
    audio.currentTime = value
    setCurrentTime(value)
  }

  const seekRatio = (ratio) => {
    const audio = audioRef.current
    if (!audio || !Number.isFinite(audio.duration) || audio.duration <= 0) return
    seekTo(audio.duration * clamp(ratio, 0, 1))
  }

  const nextTrack = () => {
    if (!tracks.length) return
    const idx = currentIndex >= 0 ? currentIndex : 0
    const next = tracks[(idx + 1) % tracks.length]
    if (next) setCurrentTrackId(next.id)
  }

  const prevTrack = () => {
    if (!tracks.length) return
    if (audioRef.current && audioRef.current.currentTime > 5) {
      audioRef.current.currentTime = 0
      return
    }
    const idx = currentIndex >= 0 ? currentIndex : 0
    const prev = tracks[(idx - 1 + tracks.length) % tracks.length]
    if (prev) setCurrentTrackId(prev.id)
  }

  const toggleMute = () => setMuted((v) => !v)
  const setPlayerVolume = (nextVolume) => {
    const v = clamp(Number(nextVolume), 0, 1)
    setVolume(v)
    setMuted(v === 0)
    if (audioRef.current) audioRef.current.volume = v
  }

  const value = {
    tracks,
    setTracks,
    currentTrack,
    currentTrackId,
    isPlaying,
    currentTime,
    duration,
    volume,
    muted,
    repeat,
    setRepeat,
    playTrack,
    togglePlay,
    play,
    pause,
    nextTrack,
    prevTrack,
    seekTo,
    seekRatio,
    toggleMute,
    setPlayerVolume,
  }

  return (
    <MusicPlayerContext.Provider value={value}>
      {children}
      <audio ref={audioRef} preload="metadata" className="sr-only" aria-hidden="true" />
    </MusicPlayerContext.Provider>
  )
}
