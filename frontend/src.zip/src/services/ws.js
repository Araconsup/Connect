import { API_BASE } from './api'

function wsBaseCandidates() {
  const candidates = []

  try {
    const apiUrl = new URL(API_BASE, window.location.href)
    apiUrl.protocol = apiUrl.protocol === 'https:' ? 'wss:' : 'ws:'
    candidates.push(apiUrl.origin)
  } catch (e) {}

  const host = window.location.hostname || 'localhost'
  const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws'
  candidates.push(`${protocol}://${host}:8000`)
  candidates.push(`${protocol}://0.0.0.0:8000`)
  candidates.push(`${protocol}://localhost:8000`)

  return [...new Set(candidates)]
}

function buildUrls(room, token) {
  const encodedRoom = encodeURIComponent(room)
  const list = []
  const queryVariants = token ? [
    `?token=${encodeURIComponent(token)}`,
    `?access_token=${encodeURIComponent(token)}`,
    `?auth=${encodeURIComponent(token)}`,
    ''
  ] : ['']

  for (const base of wsBaseCandidates()) {
    for (const query of queryVariants) {
      list.push(`${base}/ws/chat/${encodedRoom}/${query}`)
    }
  }

  return [...new Set(list)]
}

export function connectToChat(onMessage, onOpen, room = 'public', handlers = {}) {
  const token = localStorage.getItem('token') || ''
  const urls = buildUrls(room, token)
  let ws = null
  let index = 0
  let closedByUser = false
  let connected = false
  let currentUrl = ''

  const connectNext = () => {
    if (closedByUser) return
    if (index >= urls.length) {
      if (handlers.onError) handlers.onError(new Error('Unable to connect to websocket'))
      return
    }

    currentUrl = urls[index++]
    ws = new WebSocket(currentUrl)

    ws.onopen = () => {
      connected = true
      if (onOpen) onOpen()
    }

    ws.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data)
        if (onMessage) onMessage(data)
      } catch (err) {
        console.error('Invalid ws message', err)
      }
    }

    ws.onclose = () => {
      if (closedByUser) return
      if (!connected) {
        connectNext()
        return
      }
      if (handlers.onClose) handlers.onClose()
    }

    ws.onerror = () => {
      if (closedByUser) return
      try { ws.close() } catch (e) {}
    }
  }

  connectNext()

  return {
    get readyState() { return ws ? ws.readyState : WebSocket.CLOSED },
    get url() { return currentUrl },
    send(payload) { if (ws && ws.readyState === WebSocket.OPEN) ws.send(payload) },
    close() {
      closedByUser = true
      if (ws) {
        try { ws.close() } catch (e) {}
      }
    },
  }
}
