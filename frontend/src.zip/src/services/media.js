export function getMediaKind(file) {
  if (!file) return 'unknown'

  const type = typeof file === 'string' ? '' : (file.type || '')
  if (type.startsWith('audio/')) return 'audio'
  if (type.startsWith('video/')) return 'video'
  if (type.startsWith('image/')) return 'image'

  const url = typeof file === 'string' ? file : (file.url || file.src || file.path || file.file || '')
  const lower = String(url).toLowerCase()
  if (/\.(png|jpe?g|gif|webp|bmp|svg)(\?.*)?$/.test(lower)) return 'image'
  if (/\.(mp4|webm|mov|m4v|ogg)(\?.*)?$/.test(lower)) return 'video'
  if (/\.(mp3|wav|aac|m4a|flac|oga|opus)(\?.*)?$/.test(lower)) return 'audio'
  return 'other'
}

export function formatFileSize(bytes) {
  if (typeof bytes !== 'number' || Number.isNaN(bytes)) return ''
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

export function pictureToObjectUrl(picture) {
  if (!picture?.data) return null
  try {
    const payload = picture.data instanceof Uint8Array ? picture.data : new Uint8Array(picture.data)
    const blob = new Blob([payload], { type: picture.format || 'image/jpeg' })
    return URL.createObjectURL(blob)
  } catch (error) {
    return null
  }
}

export function revokeObjectUrl(url) {
  if (!url) return
  try {
    URL.revokeObjectURL(url)
  } catch (error) {
    // ignore
  }
}

function decodeText(bytes, encoding = 0) {
  if (!bytes || bytes.length === 0) return ''
  try {
    if (encoding === 1 || encoding === 2) return new TextDecoder('utf-16le').decode(bytes).replace(/\u0000+$/g, '').trim()
    if (encoding === 3) return new TextDecoder('utf-8').decode(bytes).replace(/\u0000+$/g, '').trim()
    return new TextDecoder('iso-8859-1').decode(bytes).replace(/\u0000+$/g, '').trim()
  } catch (error) {
    return ''
  }
}

function readNullTerminated(view, start, encoding = 0) {
  let end = start
  const limit = view.byteLength

  if (encoding === 1 || encoding === 2) {
    while (end + 1 < limit) {
      if (view.getUint8(end) === 0 && view.getUint8(end + 1) === 0) break
      end += 2
    }
    return { text: decodeText(new Uint8Array(view.buffer, view.byteOffset + start, Math.max(0, end - start)), encoding), next: Math.min(limit, end + 2) }
  }

  while (end < limit && view.getUint8(end) !== 0) end += 1
  return { text: decodeText(new Uint8Array(view.buffer, view.byteOffset + start, Math.max(0, end - start)), encoding), next: Math.min(limit, end + 1) }
}

function readSynchsafeInt(bytes, offset) {
  return ((bytes[offset] & 0x7f) << 21) | ((bytes[offset + 1] & 0x7f) << 14) | ((bytes[offset + 2] & 0x7f) << 7) | (bytes[offset + 3] & 0x7f)
}

function readFrameSize(bytes, offset, version) {
  if (version === 4) return readSynchsafeInt(bytes, offset)
  return (((bytes[offset] << 24) >>> 0) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3]) >>> 0
}

export async function readAudioMetadata(file) {
  try {
    if (!file?.arrayBuffer) return {}
    const buffer = await file.arrayBuffer()
    const bytes = new Uint8Array(buffer)
    if (bytes.length < 10) return {}
    if (String.fromCharCode(bytes[0], bytes[1], bytes[2]) !== 'ID3') return {}

    const version = bytes[3]
    const tagSize = readSynchsafeInt(bytes, 6)
    const view = new DataView(buffer)
    let offset = 10
    const end = Math.min(bytes.length, 10 + tagSize)
    const result = { title: '', artist: '', album: '', picture: null }

    while (offset + 10 <= end) {
      const frameId = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3])
      if (!frameId.trim()) break
      const frameSize = readFrameSize(bytes, offset + 4, version)
      if (!frameSize || offset + 10 + frameSize > bytes.length) break

      const frameDataStart = offset + 10
      const frameDataEnd = frameDataStart + frameSize
      const frameBytes = bytes.slice(frameDataStart, frameDataEnd)

      if (frameId === 'TIT2' || frameId === 'TPE1' || frameId === 'TALB') {
        const encoding = frameBytes[0] || 0
        const text = decodeText(frameBytes.slice(1), encoding)
        if (frameId === 'TIT2' && text) result.title = text
        if (frameId === 'TPE1' && text) result.artist = text
        if (frameId === 'TALB' && text) result.album = text
      }

      if (frameId === 'APIC' || frameId === 'PIC') {
        const encoding = frameBytes[0] || 0
        let cursor = 1
        let mime = ''
        if (frameId === 'APIC') {
          while (cursor < frameBytes.length && frameBytes[cursor] !== 0) {
            mime += String.fromCharCode(frameBytes[cursor])
            cursor += 1
          }
          cursor += 1
        } else {
          const fmt = String.fromCharCode(frameBytes[cursor], frameBytes[cursor + 1], frameBytes[cursor + 2])
          mime = fmt === 'PNG' ? 'image/png' : fmt === 'JPG' ? 'image/jpeg' : 'image/jpeg'
          cursor += 3
        }

        cursor += 1 // picture type
        const desc = readNullTerminated(new DataView(frameBytes.buffer, frameBytes.byteOffset, frameBytes.byteLength), cursor, encoding)
        cursor = desc.next
        const imageBytes = frameBytes.slice(cursor)
        if (imageBytes.length > 0) {
          result.picture = { data: imageBytes, format: mime || 'image/jpeg' }
        }
      }

      offset = frameDataEnd
    }

    return result
  } catch (error) {
    return {}
  }
}
