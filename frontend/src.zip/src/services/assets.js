export function publicAsset(path) {
  if (!path) return path
  if (path.startsWith('http://') || path.startsWith('https://') || path.startsWith('blob:') || path.startsWith('data:')) {
    return path
  }
  if (path.startsWith('/')) return path
  return `/${path}`
}

export function avatarUrl(user) {
  const candidate = user?.profile_pic || user?.profile_picture || user?.avatar || user?.avatar_url || user?.image || user?.profile_image
  return publicAsset(candidate || '/default-avatar.svg')
}
