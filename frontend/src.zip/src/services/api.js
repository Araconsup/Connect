import axios from 'axios'
import { notify } from './notify'

const DEFAULT_API_BASE = `${window.location.protocol}//${window.location.hostname}:8000`
export const API_BASE = import.meta.env.VITE_API_BASE || DEFAULT_API_BASE

const client = axios.create({ baseURL: API_BASE })

function isFormData(value) {
  return typeof FormData !== 'undefined' && value instanceof FormData
}

function authHeader(token) {
  return token ? `Bearer ${token}` : undefined
}

function syncAuthHeader(token) {
  if (token) client.defaults.headers.common.Authorization = authHeader(token)
  else delete client.defaults.headers.common.Authorization
}

export function setAuthFromStorage() {
  syncAuthHeader(localStorage.getItem('token'))
}

setAuthFromStorage()

client.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  const url = config.url || ''
  const method = String(config.method || 'get').toLowerCase()

  if (!config.headers) config.headers = {}
  if (!url.includes('/api/token/')) {
    const header = authHeader(token)
    if (header) config.headers.Authorization = header
  }

  if (isFormData(config.data)) {
    delete config.headers['Content-Type']
    delete config.headers['content-type']
  } else if (method !== 'get' && method !== 'head') {
    if (!config.headers['Content-Type'] && !config.headers['content-type']) {
      config.headers['Content-Type'] = 'application/json'
    }
  } else {
    delete config.headers['Content-Type']
    delete config.headers['content-type']
  }

  return config
})

client.interceptors.response.use(
  (res) => {
    if (res.status === 201) notify('Created', 'success')
    if (res.status === 204) notify('No content', 'info')
    return res
  },
  async (error) => {
    const originalRequest = error.config || {}
    const url = originalRequest.url || ''
    const status = error.response?.status
    const skipRefreshFlow = url.includes('/api/token/') || url.includes('/api/token/refresh/')

    if (status === 401 && !skipRefreshFlow && !originalRequest._retry) {
      originalRequest._retry = true
      const refresh = localStorage.getItem('refresh')
      if (refresh) {
        try {
          const r = await axios.post(`${API_BASE}/api/token/refresh/`, { refresh })
          const newAccess = r.data?.access
          if (newAccess) {
            localStorage.setItem('token', newAccess)
            syncAuthHeader(newAccess)
            if (!originalRequest.headers) originalRequest.headers = {}
            originalRequest.headers.Authorization = authHeader(newAccess)
            return client(originalRequest)
          }
        } catch (_) {
          // fall through
        }
      }

      localStorage.removeItem('token')
      localStorage.removeItem('refresh')
      syncAuthHeader(null)
      window.dispatchEvent(new Event('logout'))
      notify('Your session expired. Please sign in again.', 'error')
      return Promise.reject(error)
    }

    if (status === 400) notify('Bad request', 'error')
    else if (status === 403) notify('Forbidden', 'error')
    else if (status === 404) notify('Not found', 'warn')
    else if (status === 409) notify('Conflict', 'warn')
    else if (status === 422) notify('Validation error', 'error')
    else if (status >= 500) notify('Server error', 'error')

    return Promise.reject(error)
  }
)

export function fullUrl(pathOrUrl) {
  if (!pathOrUrl) return pathOrUrl
  if (pathOrUrl.startsWith('http://') || pathOrUrl.startsWith('https://')) return pathOrUrl
  if (pathOrUrl.startsWith('/')) return API_BASE + pathOrUrl
  return `${API_BASE}/${pathOrUrl}`
}

function normalizeLoginResponse(res, username) {
  const access = res.data?.access
  const refresh = res.data?.refresh
  if (!access) return null
  localStorage.setItem('token', access)
  if (refresh) localStorage.setItem('refresh', refresh)
  localStorage.setItem('username', username)
  syncAuthHeader(access)
  window.dispatchEvent(new Event('login'))
  return { success: true, token: access }
}

export async function login(username, password) {
  const candidates = [{ username, password }, { email: username, password }]
  for (const payload of candidates) {
    try {
      const res = await client.post('/api/token/', payload)
      const normalized = normalizeLoginResponse(res, username)
      if (normalized) return normalized
    } catch (e) {
      if (!e.response || e.response.status !== 401) {
        return { success: false, error: e.response?.data || e.message }
      }
    }
  }

  try {
    const params = new URLSearchParams()
    params.append('username', username)
    params.append('password', password)
    const res = await axios.post(`${API_BASE}/api/token/`, params.toString(), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    })
    const normalized = normalizeLoginResponse(res, username)
    if (normalized) return normalized
    return { success: false, error: res.data }
  } catch (e) {
    return { success: false, error: e.response?.data || e.message }
  }
}

export async function fetchFeed() {
  if (!localStorage.getItem('token')) return []
  const [postsRes, connectsRes] = await Promise.allSettled([
    client.get('/api/posts/'),
    client.get('/api/connects/'),
  ])
  const posts = postsRes.status === 'fulfilled' ? (postsRes.value.data || []).map((p) => ({ kind: 'post', ...p })) : []
  const connects = connectsRes.status === 'fulfilled' ? (connectsRes.value.data || []).map((c) => ({ kind: 'connect', ...c })) : []
  return [...posts, ...connects].sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0))
}

export async function fetchReels() {
  const res = await client.get('/api/reels/')
  return res.data
}

export async function fetchMusic() {
  const res = await client.get('/api/musics/')
  return res.data
}

export async function createPost(formData) {
  if (!localStorage.getItem('token')) throw { response: { status: 401, data: 'Not authenticated' } }
  const res = await client.post('/api/posts/', formData)
  return res.data
}

export async function createReel(formData) {
  if (!localStorage.getItem('token')) throw { response: { status: 401, data: 'Not authenticated' } }
  const res = await client.post('/api/reels/', formData)
  return res.data
}

export async function uploadMusic(formData) {
  if (!localStorage.getItem('token')) throw { response: { status: 401, data: 'Not authenticated' } }
  const res = await client.post('/api/musics/', formData)
  return res.data
}

export async function createConnect(data) {
  if (!localStorage.getItem('token')) throw { response: { status: 401, data: 'Not authenticated' } }
  const res = await client.post('/api/connects/', data)
  return res.data
}

export async function getProfile(username) {
  const candidates = []
  if (username && username !== 'me') candidates.push(() => client.get('/api/users/', { params: { username } }))
  candidates.push(() => client.get('/api/users/me/'))
  candidates.push(() => client.get('/api/profile/'))

  for (const run of candidates) {
    try {
      const res = await run()
      const data = res.data
      if (Array.isArray(data) && data.length > 0) return data[0]
      if (data && typeof data === 'object') return data
    } catch (e) {
      if (e?.response?.status !== 404 && e?.response?.status !== 401) throw e
    }
  }

  return null
}

export async function updateProfile(userId, data) {
  const res = await client.patch(`/api/users/${userId}/`, data)
  return res.data
}

function normalizeKind(kind = 'post') {
  const value = String(kind || 'post').toLowerCase()
  if (value.includes('connect')) return 'connects'
  if (value.includes('reel')) return 'reels'
  if (value.includes('music')) return 'musics'
  if (value.includes('user')) return 'users'
  return 'posts'
}

async function postWithFallbacks(paths, payload) {
  let lastError = null
  for (const path of paths) {
    try {
      return await client.post(path, payload)
    } catch (error) {
      lastError = error
      const status = error.response?.status
      if (status === 404 || status === 405) continue
      throw error
    }
  }
  throw lastError || new Error('Request failed')
}

function actionPaths(resource, id, action, payloadIsComment = false) {
  const base = `/api/${resource}/${id}`
  const actionNames = payloadIsComment ? ['comments', 'comment'] : [action, `${action}s`]
  const trailing = ['/', '']
  const paths = []
  for (const name of actionNames) {
    for (const slash of trailing) paths.push(`${base}/${name}${slash}`)
  }
  return paths
}

export async function likePost(postId, kind = 'post') {
  const resource = normalizeKind(kind)
  return postWithFallbacks(actionPaths(resource, postId, 'like'), null)
}

export async function commentPost(postId, text, kind = 'post') {
  const resource = normalizeKind(kind)
  const payload = { text, content: text, message: text }
  return postWithFallbacks(actionPaths(resource, postId, 'comment', true), payload)
}

export async function reportPost(postId, kind = 'post') {
  const resource = normalizeKind(kind)
  return postWithFallbacks(actionPaths(resource, postId, 'report'), null)
}

export async function blockUser(username) {
  const paths = [
    `/api/users/${username}/block/`,
    `/api/users/${username}/block`,
    `/api/block/${username}/`,
    `/api/block/${username}`,
  ]
  return postWithFallbacks(paths, null)
}
