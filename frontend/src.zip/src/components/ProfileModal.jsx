import React from 'react'
import { Link } from 'react-router-dom'
import { avatarUrl } from '../services/assets'

export default function ProfileModal({ user, onClose }) {
  if (!user) return null
  return (
    <div className="modal-backdrop" role="presentation" onClick={onClose}>
      <div className="modal-card" role="dialog" aria-modal="true" aria-label={`Profile for ${user.username}`} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="modal-close" type="button" aria-label="Close profile">Close</button>
        <div className="modal-content">
          <img src={avatarUrl(user)} alt="" className="profile-avatar" onError={(e) => { e.currentTarget.src = '/default-avatar.svg' }} />
          <div>
            <h3>@{user.username}</h3>
            <div className="muted">{user.bio}</div>
            <Link to={`/profile/${user.username}`} onClick={onClose}>View profile</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
