import React from 'react'
import Icon from './Icon'
import { fullUrl } from '../services/api'
import { useMusicPlayer } from '../context/MusicPlayerContext'
import { useLocation } from 'react-router-dom'

function formatTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = String(Math.floor(seconds % 60)).padStart(2, '0')
  return `${m}:${s}`
}

export default function GlobalMusicPlayer() {
  const location = useLocation()
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    muted,
    repeat,
    togglePlay,
    prevTrack,
    nextTrack,
    seekRatio,
    setPlayerVolume,
    toggleMute,
    setRepeat,
  } = useMusicPlayer()

  const showPlayer =
    Boolean(currentTrack && isPlaying) &&
    location.pathname !== '/music' &&
    !location.pathname.toLowerCase().includes('/reels')

  if (!showPlayer) return null

  const pct = duration ? Math.min(100, (currentTime / duration) * 100) : 0
  const title = currentTrack?.title || 'No track selected'
  const artist = currentTrack?.artist || currentTrack?.user?.username || 'Open Music to play a track'
  const cover = currentTrack?.cover ? fullUrl(currentTrack.cover) : null

  const onSeek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = (e.clientX - rect.left) / rect.width
    seekRatio(ratio)
  }

  return (
    <header className="global-player" aria-label="Music player">
      <div className="global-player-left">
        <div className="global-player-art">
          {cover ? <img src={cover} alt="Album art" /> : <div className="global-player-placeholder">♪</div>}
        </div>
        <div className="global-player-meta">
          <strong>{title}</strong>
          <span>{artist}</span>
        </div>
      </div>

      <div className="global-player-center">
        <div className="global-player-controls">
          <button type="button" className="icon-btn" onClick={prevTrack} aria-label="Previous track"><Icon name="prev" /></button>
          <button type="button" className="play-btn" onClick={togglePlay} aria-label={isPlaying ? 'Pause' : 'Play'}><Icon name={isPlaying ? 'pause' : 'play'} size={22} /></button>
          <button type="button" className="icon-btn" onClick={nextTrack} aria-label="Next track"><Icon name="next" /></button>
        </div>
        <div className="global-player-timeline">
          <span>{formatTime(currentTime)}</span>
          <button type="button" className="timeline-track" onClick={onSeek} aria-label="Seek track">
            <span style={{ width: `${pct}%` }} />
          </button>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      <div className="global-player-right">
        <button type="button" className={`mini-chip ${repeat !== 'off' ? 'active' : ''}`} onClick={() => setRepeat(repeat === 'off' ? 'all' : repeat === 'all' ? 'one' : 'off')}>
          {repeat === 'one' ? '1' : '↻'}
        </button>
        <button type="button" className="icon-btn" onClick={toggleMute} aria-label={muted || volume === 0 ? 'Unmute' : 'Mute'}>
          <Icon name={muted || volume === 0 ? 'volumeMute' : 'volume'} />
        </button>
        <input className="volume-slider" type="range" min="0" max="1" step="0.01" value={muted ? 0 : volume} onChange={(e) => setPlayerVolume(e.target.value)} aria-label="Volume" />
      </div>
    </header>
  )
}
