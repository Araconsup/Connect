import React, { useEffect, useState } from 'react'
import { setNotifyHandler } from '../services/notify'

export default function Notifications() {
  const [items, setItems] = useState([])

  useEffect(() => {
    setNotifyHandler((n) => {
      if (!n) return
      const id = Date.now() + Math.random()
      setItems((prev) => [...prev, { id, ...n }])
      setTimeout(() => setItems((prev) => prev.filter((x) => x.id !== id)), 4200)
    })
    return () => setNotifyHandler(null)
  }, [])

  return (
    <div className="toast-stack">
      {items.map((it) => (
        <div key={it.id} className={`toast toast-${it.type || 'info'}`}>
          {it.message}
        </div>
      ))}
    </div>
  )
}
