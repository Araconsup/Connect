import React from 'react'
import { NavLink } from 'react-router-dom'
import Icon from './Icon'

const items = [
  { to: '/', icon: 'home', label: 'Home' },
  { to: '/reels', icon: 'reels', label: 'Reels' },
  { to: '/upload', icon: 'upload', label: 'Create' },
  { to: '/chat', icon: 'chat', label: 'Chat' },
  { to: '/music', icon: 'music', label: 'Music' },
]

export default function BottomNav() {
  const username = localStorage.getItem('username') || 'me'
  return (
    <nav className="bottom-nav glass-panel" aria-label="Primary navigation">
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}
          end={item.to === '/'}
        >
          <Icon name={item.icon} />
          <span>{item.label}</span>
        </NavLink>
      ))}
      <NavLink
        to={`/profile/${username}`}
        className={({ isActive }) => `nav-btn ${isActive ? 'active' : ''}`}
      >
        <Icon name="profile" />
        <span>Profile</span>
      </NavLink>
    </nav>
  )
}
