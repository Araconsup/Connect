import React, { memo, useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { fullUrl, likePost } from '../services/api'
import Icon from './Icon'
import { avatarUrl } from '../services/assets'

function formatCount(value = 0) {
  const n = Number(value) || 0
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(n >= 10_000 ? 0 : 1)}K`
  return `${n}`
}

function VideoReel({ reel, index = 0, total = 1 }) {
  const vidRef = useRef(null)
  const containerRef = useRef(null)
  const tapTimerRef = useRef(null)
  const [liked, setLiked] = useState(Boolean(reel?.is_liked || reel?.liked))
  const [bookmarked, setBookmarked] = useState(Boolean(reel?.is_saved || reel?.saved))
  const [muted, setMuted] = useState(true)
  const [paused, setPaused] = useState(false)
  const [progress, setProgress] = useState(0)
  const [showHeart, setShowHeart] = useState(false)

  const src = useMemo(() => fullUrl(reel?.video?.url || reel?.video || reel?.video_url), [reel])
  const poster = useMemo(() => fullUrl(reel?.cover?.url || reel?.thumbnail?.url || reel?.thumbnail || reel?.poster), [reel])

  useEffect(() => {
    const el = containerRef.current
    if (!el) return

    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const v = vidRef.current
          if (!v) return
          if (entry.isIntersecting && entry.intersectionRatio >= 0.72) {
            v.play().catch(() => {})
            setPaused(false)
          } else {
            v.pause()
            setPaused(true)
          }
        })
      },
      { threshold: [0.45, 0.72, 0.9] }
    )

    obs.observe(el)
    return () => obs.disconnect()
  }, [])

  useEffect(() => {
    const video = vidRef.current
    if (!video) return
    video.muted = muted
  }, [muted])

  useEffect(() => {
    const onVisibilityChange = () => {
      const video = vidRef.current
      if (!video) return
      if (document.hidden) video.pause()
    }
    document.addEventListener('visibilitychange', onVisibilityChange)
    return () => document.removeEventListener('visibilitychange', onVisibilityChange)
  }, [])

  useEffect(() => () => clearTimeout(tapTimerRef.current), [])

  async function toggleLike() {
    try {
      setLiked((value) => !value)
      await likePost(reel.id, 'reel')
      setShowHeart(true)
      window.setTimeout(() => setShowHeart(false), 900)
    } catch (e) {
      setLiked((value) => value)
    }
  }

  function toggleBookmark() {
    setBookmarked((value) => !value)
  }

  function toggleMute() {
    setMuted((value) => !value)
  }

  function togglePlay() {
    const video = vidRef.current
    if (!video) return
    if (video.paused) {
      video.play().catch(() => {})
      setPaused(false)
    } else {
      video.pause()
      setPaused(true)
    }
  }

  function handleTap() {
    if (tapTimerRef.current) {
      clearTimeout(tapTimerRef.current)
      tapTimerRef.current = null
      toggleLike()
      return
    }

    tapTimerRef.current = window.setTimeout(() => {
      togglePlay()
      tapTimerRef.current = null
    }, 220)
  }

  function handleTimeUpdate() {
    const video = vidRef.current
    if (!video || !video.duration) return
    setProgress((video.currentTime / video.duration) * 100)
  }

  const authorName = reel?.user?.username || reel?.author?.username || reel?.username || 'unknown'
  const avatar = avatarUrl(reel?.user || reel?.author)
  const caption = reel?.caption || reel?.description || ''
  const musicLabel = reel?.music?.title || reel?.music_title || reel?.sound_name || reel?.audio_title || 'Original audio'
  const likes = formatCount(reel?.likes_count ?? reel?.like_count ?? reel?.likes ?? (liked ? 1 : 0))
  const comments = formatCount(reel?.comments_count ?? reel?.comment_count ?? reel?.comments ?? 0)
  const shares = formatCount(reel?.shares_count ?? reel?.share_count ?? reel?.shares ?? 0)

  return (
    <article
      ref={containerRef}
      className="reel-stage"
      aria-label={`Reel ${index + 1} of ${total}`}
      onClick={handleTap}
    >
      <video
        ref={vidRef}
        src={src}
        poster={poster}
        playsInline
        loop
        muted={muted}
        preload="metadata"
        className="reel-video"
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleTimeUpdate}
      />

      <div className="reel-gradient reel-gradient-top" />
      <div className="reel-gradient reel-gradient-bottom" />

      <div className="reel-progress" aria-hidden="true">
        <span style={{ width: `${progress}%` }} />
      </div>

      <div className="reel-shell">
        <div className="reel-top-meta">
          <div className="reel-badge">
            <span className="reel-live-dot" />
            <span>Shorts-style feed</span>
          </div>
          <span className="reel-counter">{index + 1}/{total}</span>
        </div>

        <div className="reel-hero-copy">
          <Link to={`/profile/${authorName}`} className="reel-author" onClick={(e) => e.stopPropagation()}>
            <img
              src={avatar || '/default-avatar.svg'}
              alt={`${authorName} avatar`}
              className="reel-avatar"
            />
            <div>
              <strong>@{authorName}</strong>
              <span>{reel?.created_at ? new Date(reel.created_at).toLocaleDateString() : 'Now playing'}</span>
            </div>
          </Link>

          {caption ? <p className="reel-caption">{caption}</p> : <p className="reel-caption muted">Tap to pause. Double tap to like.</p>}

          <div className="reel-audio-chip" aria-label="Audio information">
            <Icon name="music" size={16} />
            <span>{musicLabel}</span>
          </div>
        </div>

        <aside className="reel-actions" aria-label="Reel actions" onClick={(e) => e.stopPropagation()}>
          <button type="button" className={`reel-action ${liked ? 'active' : ''}`} onClick={toggleLike} aria-label={liked ? 'Unlike reel' : 'Like reel'}>
            <span className="reel-action-icon">♥</span>
            <span>{likes}</span>
          </button>

          <button type="button" className="reel-action" aria-label="Open comments">
            <span className="reel-action-icon">◌</span>
            <span>{comments}</span>
          </button>

          <button type="button" className="reel-action" aria-label="Share reel">
            <span className="reel-action-icon">↗</span>
            <span>{shares}</span>
          </button>

          <button type="button" className={`reel-action ${bookmarked ? 'active' : ''}`} onClick={toggleBookmark} aria-label={bookmarked ? 'Remove save' : 'Save reel'}>
            <span className="reel-action-icon">⌁</span>
            <span>Save</span>
          </button>

          <button type="button" className="reel-action" onClick={toggleMute} aria-label={muted ? 'Unmute video' : 'Mute video'}>
            <span className="reel-action-icon">{muted ? '🔇' : '🔊'}</span>
            <span>{muted ? 'Muted' : 'Sound'}</span>
          </button>
        </aside>

        <button
          type="button"
          className="reel-play-toggle"
          onClick={(e) => {
            e.stopPropagation()
            togglePlay()
          }}
          aria-label={paused ? 'Play video' : 'Pause video'}
        >
          {paused ? 'Play' : 'Pause'}
        </button>

        {showHeart && <div className="reel-heart" aria-hidden="true">♥</div>}
      </div>
    </article>
  )
}


export default memo(VideoReel)
