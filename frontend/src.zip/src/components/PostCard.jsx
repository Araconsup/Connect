import React, { memo, useMemo, useState } from 'react'
import { likePost, reportPost, blockUser, commentPost, fullUrl } from '../services/api'
import { avatarUrl } from '../services/assets'
import { getMediaKind } from '../services/media'

function pickMediaValue(item) {
  if (!item) return null
  if (typeof item === 'string') return item
  return item.url || item.file || item.path || item.src || null
}

function normalizeMediaItems(post) {
  const items = []
  const source = Array.isArray(post?.media_files) ? post.media_files : []

  source.forEach((item, index) => {
    const value = pickMediaValue(item)
    if (!value) return
    const mediaKind = getMediaKind(item)
    const kind = mediaKind !== 'other' ? mediaKind : getMediaKind(value)
    items.push({ key: item?.id ?? `${post?.id || 'post'}-${index}`, src: fullUrl(value), kind })
  })

  const fallback = [
    post?.media?.url,
    post?.media?.file,
    post?.media?.path,
    post?.media_url,
    post?.image?.url,
    post?.image?.file,
    post?.image?.path,
    post?.image_url,
    post?.file?.url,
    post?.file?.file,
    post?.file?.path,
    post?.file_url,
  ].find(Boolean)

  if (items.length === 0 && fallback) {
    items.push({ key: `${post?.id || 'post'}-fallback`, src: fullUrl(fallback), kind: getMediaKind(fallback) })
  }

  return items.filter((item) => item.src)
}

function PostCard({ post }) {
  const [liked, setLiked] = useState(Boolean(post?.is_liked || post?.liked))
  const [likeCount, setLikeCount] = useState(Number(post?.likes_count || 0))
  const [commentText, setCommentText] = useState('')
  const [commentCount, setCommentCount] = useState(Number(post?.comments_count || post?.comment_count || 0))
  const [showComments, setShowComments] = useState(false)
  const [busy, setBusy] = useState(false)

  const mediaItems = useMemo(() => normalizeMediaItems(post), [post])
  const author = post?.user?.username || post?.author?.username || 'unknown'
  const avatar = avatarUrl(post?.user || post?.author)
  const tags = Array.isArray(post?.tags) ? post.tags : []
  const isConnect = post?.kind === 'connect' || Boolean(post?.text && !post?.caption)
  const bodyText = post?.caption || post?.text || ''
  const resourceKind = isConnect ? 'connect' : 'post'

  const handleLike = async () => {
    if (busy) return
    try {
      setBusy(true)
      const nextLiked = !liked
      await likePost(post.id, resourceKind)
      setLiked(nextLiked)
      setLikeCount((v) => Math.max(0, nextLiked ? v + 1 : v - 1))
    } catch (e) {
      console.error('Like failed', e)
    } finally {
      setBusy(false)
    }
  }

  const handleComment = async () => {
    if (busy || !commentText.trim()) return
    try {
      setBusy(true)
      await commentPost(post.id, commentText.trim(), resourceKind)
      setCommentText('')
      setCommentCount((v) => v + 1)
      setShowComments(true)
    } catch (e) {
      console.error('Comment failed', e)
    } finally {
      setBusy(false)
    }
  }

  const handleReport = async () => { try { await reportPost(post.id, resourceKind) } catch (e) { console.error(e) } }
  const handleBlock = async () => { try { if (author !== 'unknown') await blockUser(author) } catch (e) { console.error(e) } }

  return (
    <article className={`surface post-card ${mediaItems.length ? 'post-card-media' : ''}`}>
      <header className="card-head">
        <div className="avatar-wrap">
          <img src={avatar || '/default-avatar.svg'} alt="" className="avatar" loading="lazy" decoding="async" onError={(e) => { e.currentTarget.src = '/default-avatar.svg' }} />
        </div>
        <div className="card-meta">
          <strong>@{author}</strong>
          <span>{isConnect ? 'Connect' : 'Post'} · {post?.created_at ? new Date(post.created_at).toLocaleString() : 'Just now'}</span>
        </div>
      </header>

      <div className="post-body">
        {bodyText && <p>{bodyText}</p>}

        {tags.length > 0 && (
          <div className="tag-row" aria-label="Tags">
            {tags.map((t) => <span key={t} className="tag-chip">#{t}</span>)}
          </div>
        )}

        {mediaItems.length === 1 && mediaItems[0].kind === 'image' && (
          <img src={mediaItems[0].src} alt="post media" className="post-media" loading="lazy" decoding="async" />
        )}
        {mediaItems.length === 1 && mediaItems[0].kind === 'video' && (
          <video src={mediaItems[0].src} controls playsInline preload="metadata" className="post-media" />
        )}

        {mediaItems.length > 1 && (
          <div className="media-grid" aria-label="Post media gallery">
            {mediaItems.map((item) => (
              <div key={item.key} className={`media-tile ${item.kind}`}>
                {item.kind === 'video' ? (
                  <video src={item.src} controls playsInline preload="metadata" />
                ) : (
                  <img src={item.src} alt="post media" loading="lazy" decoding="async" />
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <footer className="card-actions">
        <button className={`btn btn-ghost ${liked ? 'active' : ''}`} type="button" onClick={handleLike} aria-pressed={liked}>Like {likeCount}</button>
        <button className="btn btn-ghost" type="button" onClick={() => setShowComments((v) => !v)} aria-expanded={showComments}>Comment {commentCount}</button>
        <button className="btn btn-ghost" type="button" onClick={handleBlock}>Block</button>
        <button className="btn btn-ghost" type="button" onClick={handleReport}>Report</button>
      </footer>

      {showComments && (
        <div className="comment-box" aria-label="Add comment">
          <label className="field-label" htmlFor={`comment-${post.id}`}>Add a comment</label>
          <div className="comment-row">
            <input
              id={`comment-${post.id}`}
              className="text-input"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Write a comment and press Post"
              onKeyDown={(e) => { if (e.key === 'Enter') handleComment() }}
            />
            <button type="button" className="btn btn-primary" onClick={handleComment} disabled={busy || !commentText.trim()}>Post</button>
          </div>
        </div>
      )}
    </article>
  )
}

export default memo(PostCard)
