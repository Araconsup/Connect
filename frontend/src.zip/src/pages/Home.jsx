import React, { useEffect, useMemo, useState } from 'react'
import { fetchFeed } from '../services/api'
import PostCard from '../components/PostCard'
import Icon from '../components/Icon'

export default function Home() {
  const [posts, setPosts] = useState([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('all')

  useEffect(() => {
    let alive = true
    setLoading(true)

    fetchFeed()
      .then((data) => {
        if (alive) setPosts(data || [])
      })
      .catch(() => {
        if (alive) setPosts([])
      })
      .finally(() => {
        if (alive) setLoading(false)
      })

    return () => { alive = false }
  }, [])

  const stats = useMemo(() => {
    const mediaPosts = posts.filter((post) => Array.isArray(post?.media_files) ? post.media_files.length > 0 : Boolean(post?.media || post?.image || post?.file || post?.media_url || post?.image_url || post?.file_url))
    const connectPosts = posts.filter((post) => post?.kind === 'connect' || Boolean(post?.text && !post?.caption))
    return { total: posts.length, media: mediaPosts.length, connects: connectPosts.length }
  }, [posts])

  const visiblePosts = useMemo(() => {
    if (tab === 'media') {
      return posts.filter((post) => Array.isArray(post?.media_files) ? post.media_files.length > 0 : Boolean(post?.media || post?.image || post?.file || post?.media_url || post?.image_url || post?.file_url))
    }
    if (tab === 'connects') {
      return posts.filter((post) => post?.kind === 'connect' || Boolean(post?.text && !post?.caption))
    }
    return posts
  }, [posts, tab])

  return (
    <div className="page-shell home-shell">
      <section className="surface page-hero home-hero">
        <div className="hero-copy">
          <div className="eyebrow"><Icon name="spark" size={16} /> Home</div>
          <h1>Clean feed, media posts, and Connects.</h1>
          <p>Photos and videos render inline. Text-only Connect posts stay simple.</p>
        </div>
        <div className="hero-stats" aria-label="Feed summary">
          <div><strong>{loading ? '…' : stats.total}</strong><span>Items</span></div>
          <div><strong>{loading ? '…' : stats.media}</strong><span>Media</span></div>
          <div><strong>{loading ? '…' : stats.connects}</strong><span>Connects</span></div>
        </div>
      </section>

      <div className="segment-switcher surface compact-segment">
        <button type="button" className={`btn btn-chip ${tab === 'all' ? 'active' : ''}`} onClick={() => setTab('all')}>All</button>
        <button type="button" className={`btn btn-chip ${tab === 'media' ? 'active' : ''}`} onClick={() => setTab('media')}>Media</button>
        <button type="button" className={`btn btn-chip ${tab === 'connects' ? 'active' : ''}`} onClick={() => setTab('connects')}>Connects</button>
      </div>

      <section className="content-stack home-feed" aria-busy={loading} aria-live="polite">
        {!loading && visiblePosts.length === 0 && <div className="surface empty-state">No posts yet</div>}
        {visiblePosts.map((p) => <PostCard key={`${p.kind || 'item'}-${p.id}`} post={p} />)}
      </section>
    </div>
  )
}
