import React, { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { fetchReels } from '../services/api'
import VideoReel from '../components/VideoReel'
import Icon from '../components/Icon'

export default function Reels() {
  const [reels, setReels] = useState([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('for-you')

  useEffect(() => {
    let alive = true
    setLoading(true)

    fetchReels()
      .then((data) => {
        if (alive) setReels(Array.isArray(data) ? data : [])
      })
      .catch(() => {
        if (alive) setReels([])
      })
      .finally(() => {
        if (alive) setLoading(false)
      })

    return () => {
      alive = false
    }
  }, [])

  const visibleReels = useMemo(() => {
    if (tab === 'following') {
      return reels.filter((reel) => reel.is_following || reel.following || reel.user?.is_following)
    }
    return reels
  }, [reels, tab])

  return (
    <div className="reels-immersive">
      <header className="reels-topbar" aria-label="Reels navigation">
        <Link to="/" className="reels-back" aria-label="Back to home">
          <Icon name="home" size={18} />
        </Link>
        <div className="reels-tabs" role="tablist" aria-label="Reels feed tabs">
          <button
            type="button"
            className={`reels-tab ${tab === 'following' ? 'active' : ''}`}
            onClick={() => setTab('following')}
            role="tab"
            aria-selected={tab === 'following'}
          >
            Following
          </button>
          <button
            type="button"
            className={`reels-tab ${tab === 'for-you' ? 'active' : ''}`}
            onClick={() => setTab('for-you')}
            role="tab"
            aria-selected={tab === 'for-you'}
          >
            For You
          </button>
        </div>
        <div className="reels-brand" aria-hidden="true">
          <span />
        </div>
      </header>

      <main className="reels-feed" aria-busy={loading ? 'true' : 'false'}>
        {loading && (
          <div className="reels-empty-screen">
            <div className="reels-loader" aria-hidden="true" />
            <p>Loading short-form feed…</p>
          </div>
        )}

        {!loading && visibleReels.length === 0 && (
          <div className="reels-empty-screen">
            <h2>No reels yet</h2>
            <p>When videos are available, they will appear here in a full-screen swipe feed.</p>
          </div>
        )}

        {visibleReels.map((reel, index) => (
          <VideoReel key={reel.id || index} reel={reel} index={index} total={visibleReels.length} />
        ))}
      </main>
    </div>
  )
}
