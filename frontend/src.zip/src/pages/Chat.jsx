import React, { useEffect, useRef, useState } from 'react'
import { connectToChat } from '../services/ws'
import ProfileModal from '../components/ProfileModal'
import { avatarUrl } from '../services/assets'

export default function Chat() {
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  const [ws, setWs] = useState(null)
  const [profileUser, setProfileUser] = useState(null)
  const [connected, setConnected] = useState(false)
  const [error, setError] = useState('')
  const listRef = useRef(null)

  useEffect(() => {
    const socket = connectToChat(
      (msg) => {
        const m = { user: { username: msg.username, avatar: msg.avatar || '' }, text: msg.message, private: msg.private }
        setMessages((prev) => [...prev, m])
      },
      () => {
        setConnected(true)
        setError('')
      },
      'public',
      {
        onError: () => setError('Chat connection failed. Check websocket auth or backend route.'),
        onClose: () => setConnected(false),
      }
    )
    setWs(socket)
    return () => socket && socket.close()
  }, [])

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight
    }
  }, [messages])

  const send = () => {
    if (!ws || ws.readyState !== WebSocket.OPEN || !text.trim()) return
    const username = localStorage.getItem('username')
    ws.send(JSON.stringify({ message: text, username }))
    setText('')
  }

  return (
    <div className="page-shell chat-shell">
      <section className="page-hero surface">
        <div className="hero-copy">
          <div className="eyebrow">Chat</div>
          <h1>Public room</h1>
          <p>Fast messages, profile popups, and a room layout that feels more like a real messenger.</p>
        </div>
        <div className="hero-note">{connected ? 'Connected' : 'Connecting…'}{error ? ` · ${error}` : ''}</div>
      </section>

      <section className="surface chat-thread" ref={listRef} aria-live="polite" aria-label="Chat messages">
        {messages.map((m, i) => (
          <button key={i} type="button" className="chat-row" onClick={() => setProfileUser(m.user)}>
            <img src={avatarUrl(m.user)} className="avatar" alt="" onError={(e) => { e.currentTarget.src = '/default-avatar.svg' }} />
            <div>
              <strong>@{m.user?.username}</strong>
              <p>{m.text}</p>
            </div>
          </button>
        ))}
      </section>

      <section className="surface chat-compose" aria-label="Send a message">
        <label className="sr-only" htmlFor="chat-message">Message</label>
        <input id="chat-message" className="text-input" value={text} onChange={(e) => setText(e.target.value)} placeholder="Say something..." onKeyDown={(e) => { if (e.key === 'Enter') send() }} />
        <button className="btn btn-primary" type="button" onClick={send} disabled={!ws || ws.readyState !== WebSocket.OPEN}>Send</button>
      </section>

      {profileUser && <ProfileModal user={profileUser} onClose={() => setProfileUser(null)} />}
    </div>
  )
}
