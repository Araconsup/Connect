import React, { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { fetchFeed, fetchReels, getProfile, updateProfile, fullUrl } from '../services/api'
import { avatarUrl } from '../services/assets'
import PostCard from '../components/PostCard'
import VideoReel from '../components/VideoReel'

function applyThemeClass(nextTheme) {
  const classes = ['theme-dark-ghost', 'theme-emerald', 'theme-sand', 'theme-violet', 'theme-midnight']
  document.documentElement.classList.remove(...classes)
  if (nextTheme) document.documentElement.classList.add(nextTheme)
  if (nextTheme) localStorage.setItem('theme', nextTheme)
  else localStorage.removeItem('theme')
}

export default function Profile() {
  const { username: routeUsername } = useParams()
  const username = routeUsername || localStorage.getItem('username') || 'me'
  const currentUser = localStorage.getItem('username') || 'me'
  const isOwnProfile = username === currentUser || username === 'me'

  const [user, setUser] = useState(null)
  const [bio, setBio] = useState('')
  const [newUsername, setNewUsername] = useState('')
  const [oldPassword, setOldPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [theme, setTheme] = useState(localStorage.getItem('theme') || '')
  const [feed, setFeed] = useState([])
  const [reels, setReels] = useState([])
  const [activeTab, setActiveTab] = useState('posts')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    setLoading(true)
    setError('')

    Promise.allSettled([getProfile(username), fetchFeed(), fetchReels()])
      .then(([profileRes, feedRes, reelsRes]) => {
        if (!alive) return
        if (profileRes.status === 'fulfilled' && profileRes.value) {
          const u = profileRes.value
          setUser(u)
          setBio(u?.bio || '')
          setNewUsername('')
        } else if (profileRes.status === 'rejected') {
          setError(profileRes.reason?.response?.status === 401 ? 'Your session expired. Sign in again.' : 'Unable to load profile.')
        }
        if (feedRes.status === 'fulfilled') setFeed(Array.isArray(feedRes.value) ? feedRes.value : [])
        if (reelsRes.status === 'fulfilled') setReels(Array.isArray(reelsRes.value) ? reelsRes.value : [])
      })
      .finally(() => {
        if (alive) setLoading(false)
      })

    return () => { alive = false }
  }, [username])

  const scopedFeed = useMemo(() => {
    const uname = String(user?.username || username || '').toLowerCase()
    return feed.filter((item) => String(item?.user?.username || item?.author?.username || '').toLowerCase() === uname)
  }, [feed, user, username])

  const scopedReels = useMemo(() => {
    const uname = String(user?.username || username || '').toLowerCase()
    return reels.filter((item) => String(item?.user?.username || item?.author?.username || item?.username || '').toLowerCase() === uname)
  }, [reels, user, username])

  const mediaItems = useMemo(() => scopedFeed.filter((post) => Array.isArray(post?.media_files) ? post.media_files.length > 0 : Boolean(post?.media || post?.image || post?.file || post?.media_url || post?.image_url || post?.file_url)), [scopedFeed])
  const connectItems = useMemo(() => scopedFeed.filter((post) => post?.kind === 'connect' || Boolean(post?.text && !post?.caption)), [scopedFeed])
  const items = useMemo(() => {
    if (activeTab === 'media') return mediaItems
    if (activeTab === 'reels') return scopedReels
    if (activeTab === 'connects') return connectItems
    return scopedFeed
  }, [activeTab, connectItems, mediaItems, scopedFeed, scopedReels])

  const backgroundStyle = useMemo(() => ({ backgroundImage: user?.background ? `url(${fullUrl(user.background)})` : 'none' }), [user?.background])

  const saveProfile = async () => {
    try {
      if (!user) return
      await updateProfile(user.id, { bio, username: newUsername || undefined })
    } catch (e) {
      console.error(e)
    }
  }

  const doChangePassword = async () => {
    try {
      if (!user) return
      await updateProfile(user.id, { password: newPassword })
      setOldPassword('')
      setNewPassword('')
    } catch (e) {
      console.error(e)
    }
  }

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
    } catch (e) {
      console.error(e)
    }
  }

  const themeOptions = [
    { id: '', label: 'Aquamatic' },
    { id: 'theme-dark-ghost', label: 'Graphite' },
    { id: 'theme-emerald', label: 'Emerald' },
    { id: 'theme-sand', label: 'Sand' },
    { id: 'theme-violet', label: 'Violet' },
    { id: 'theme-midnight', label: 'Midnight' },
  ]

  if (loading) return <div className="page-shell"><div className="surface empty-state">Loading...</div></div>
  if (!user) return <div className="page-shell"><div className="surface empty-state">{error || 'Profile not available'}</div></div>

  return (
    <div className="page-shell profile-shell">
      <section className="surface profile-hero" style={backgroundStyle}>
        <img src={avatarUrl(user)} className="profile-avatar" alt="" loading="lazy" decoding="async" onError={(e) => { e.currentTarget.src = '/default-avatar.svg' }} />
        <div className="profile-hero-copy">
          <div className="eyebrow">@{user.username}</div>
          <h1>{user.username}</h1>
          <p>{user.bio || 'No bio yet.'}</p>
          <div className="profile-actions">
            <button className="btn btn-primary" type="button" onClick={copyLink}>Copy link</button>
            <Link className="btn btn-ghost" to="/chat">Message</Link>
          </div>
        </div>
      </section>

      <section className="surface profile-stats">
        <div><strong>{scopedFeed.length}</strong><span>Posts</span></div>
        <div><strong>{mediaItems.length}</strong><span>Media</span></div>
        <div><strong>{connectItems.length}</strong><span>Connects</span></div>
        <div><strong>{scopedReels.length}</strong><span>Reels</span></div>
      </section>

      <section className="surface segment-switcher compact-segment">
        <button type="button" className={`btn btn-chip ${activeTab === 'posts' ? 'active' : ''}`} onClick={() => setActiveTab('posts')}>Posts</button>
        <button type="button" className={`btn btn-chip ${activeTab === 'media' ? 'active' : ''}`} onClick={() => setActiveTab('media')}>Media</button>
        <button type="button" className={`btn btn-chip ${activeTab === 'connects' ? 'active' : ''}`} onClick={() => setActiveTab('connects')}>Connects</button>
        <button type="button" className={`btn btn-chip ${activeTab === 'reels' ? 'active' : ''}`} onClick={() => setActiveTab('reels')}>Reels</button>
      </section>

      <section className="content-stack profile-stream">
        {items.length === 0 && <div className="surface empty-state">Nothing here yet.</div>}
        {activeTab === 'reels' ? items.map((reel, index) => <VideoReel key={reel.id || index} reel={reel} index={index} total={items.length} />) : items.map((p) => <PostCard key={`${p.kind || 'item'}-${p.id}`} post={p} />)}
      </section>

      {isOwnProfile && (
        <div className="grid-two profile-grid">
          <section className="surface form-card">
            <h3>Edit profile</h3>
            <label className="field-label">Bio</label>
            <textarea className="text-area" value={bio} onChange={(e) => setBio(e.target.value)} />
            <label className="field-label">Username</label>
            <input className="text-input" placeholder={user.username} value={newUsername} onChange={(e) => setNewUsername(e.target.value)} />
            <button className="btn btn-primary" type="button" onClick={saveProfile}>Save changes</button>
          </section>

          <section className="surface form-card">
            <h3>Password</h3>
            <input className="text-input" type="password" placeholder="Old password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} />
            <input className="text-input" type="password" placeholder="New password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            <button className="btn btn-primary" type="button" onClick={doChangePassword}>Change password</button>
          </section>
        </div>
      )}

      <section className="surface form-card">
        <h3>Themes</h3>
        <div className="theme-switcher theme-grid">
          {themeOptions.map((option) => (
            <button
              key={option.id || 'default'}
              type="button"
              className={`btn btn-chip ${theme === option.id ? 'active' : ''}`}
              onClick={() => { applyThemeClass(option.id); setTheme(option.id) }}
            >
              {option.label}
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}
