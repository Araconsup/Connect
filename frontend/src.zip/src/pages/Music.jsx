import React, { useEffect, useMemo, useState } from 'react'
import { fetchMusic, fullUrl } from '../services/api'
import { useMusicPlayer } from '../context/MusicPlayerContext'

function formatTrackArtist(track) {
  return track?.artist || track?.user?.username || 'Unknown artist'
}

export default function Music() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const { tracks, setTracks, currentTrack, currentTrackId, playTrack, isPlaying, togglePlay, nextTrack, prevTrack } = useMusicPlayer()

  useEffect(() => {
    let alive = true
    setLoading(true)
    setError('')
    fetchMusic()
      .then((data) => {
        if (!alive) return
        setTracks(Array.isArray(data) ? data : [])
      })
      .catch(() => {
        if (alive) setError('Could not load your music library right now.')
      })
      .finally(() => {
        if (alive) setLoading(false)
      })
    return () => { alive = false }
  }, [setTracks])

  const selected = currentTrack || tracks[0] || null
  const selectedCover = selected?.cover ? fullUrl(selected.cover) : null

  const libraryCount = tracks.length
  const currentLabel = useMemo(() => {
    if (!currentTrack) return 'Nothing playing'
    return currentTrack.title || 'Untitled track'
  }, [currentTrack])

  return (
    <div className="page-shell music-page">
      <section className="music-hero surface">
        <div className="music-hero-copy">
          <div className="eyebrow">Your Library</div>
          <h1>Music</h1>
          <p>Pick a track and the player stays pinned at the top across every tab.</p>
        </div>
        <div className="music-hero-card">
          <span>Library</span>
          <strong>{libraryCount}</strong>
          <small>{currentTrack ? currentLabel : 'No track selected'}</small>
        </div>
      </section>

      <div className="music-grid spotify-grid">
        <section className="surface music-list spotify-list" aria-busy={loading} aria-live="polite">
          <div className="music-list-head">
            <strong>Tracks</strong>
            <span>{libraryCount} songs</span>
          </div>

          {loading && <div className="empty-state">Loading tracks…</div>}
          {!loading && error && <div className="empty-state">{error}</div>}
          {!loading && !error && tracks.length === 0 && <div className="empty-state">No tracks yet</div>}

          {tracks.map((track, index) => {
            const active = currentTrackId === track.id
            const cover = track?.cover ? fullUrl(track.cover) : null
            return (
              <button
                key={track.id}
                type="button"
                className={`spotify-track ${active ? 'active' : ''}`}
                onClick={() => playTrack(track)}
              >
                <div className="spotify-track-index">{active ? (isPlaying ? '▶' : '❚❚') : index + 1}</div>
                <div className="spotify-track-cover">
                  {cover ? <img src={cover} alt="Track cover" /> : <div>♪</div>}
                </div>
                <div className="spotify-track-meta">
                  <strong>{track.title || 'Untitled'}</strong>
                  <span>{formatTrackArtist(track)}</span>
                </div>
                <div className="spotify-track-actions">
                  <span className="spotify-track-pill">Play</span>
                </div>
              </button>
            )
          })}
        </section>

        <section className="surface spotify-now-playing">
          <div className="music-now-art">
            {selectedCover ? <img src={selectedCover} alt="Cover artwork" /> : <div className="cover-placeholder">♪</div>}
          </div>
          <div className="music-now-copy">
            <div className="eyebrow">Now playing</div>
            <h2>{selected?.title || 'Choose a track'}</h2>
            <p>{selected ? `by ${formatTrackArtist(selected)}` : 'Select a song from the list to start playback.'}</p>
          </div>
          <div className="music-now-controls">
            <button type="button" className="btn btn-ghost" onClick={prevTrack}>Previous</button>
            <button type="button" className="btn btn-primary" onClick={togglePlay} disabled={!currentTrack}>
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={nextTrack}>Next</button>
          </div>
        </section>
      </div>
    </div>
  )
}
