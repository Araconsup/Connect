import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login } from '../services/api'
import { notify } from '../services/notify'
import Icon from '../components/Icon'

export default function Login() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    const res = await login(username, password)
    if (res.success) {
      localStorage.setItem('username', username)
      window.dispatchEvent(new Event('login'))
      notify('Signed in', 'success')
      nav('/')
    } else {
      setError(res.error || 'Login failed')
      notify(res.error || 'Login failed', 'error')
    }
  }

  return (
    <div className="auth-shell">
      <div className="auth-panel auth-hero">
        <div className="eyebrow"><Icon name="spark" size={16} /> Social studio</div>
        <h1>Connect with a cleaner, faster interface.</h1>
        <p>Upload media, post reels, share music, and chat with a modern layered UI built for content-first workflows.</p>
      </div>
      <form className="auth-panel auth-card" onSubmit={submit}>
        <div className="brand-mark">C</div>
        <h2>Welcome back</h2>
        <p className="muted">Sign in to continue.</p>
        <label className="field-label">Username</label>
        <input className="text-input" value={username} onChange={(e) => setUsername(e.target.value)} required />
        <label className="field-label">Password</label>
        <input className="text-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button className="btn btn-primary btn-full" type="submit" style={{ marginTop: 14 }}>Sign in</button>
        {error && <div className="form-error">{String(error)}</div>}
      </form>
    </div>
  )
}
