import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import './index.css'

const theme = localStorage.getItem('theme')
if (theme) {
  document.documentElement.classList.remove('theme-dark-ghost', 'theme-emerald', 'theme-sand', 'theme-violet', 'theme-midnight')
  document.documentElement.classList.add(theme)
}

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
)
