import React, { useEffect, useMemo, useState } from 'react'
import { fetchMusic, fullUrl, toggleTrackLike } from '../services/api'
import { useMusicPlayer } from '../context/MusicPlayerContext'
import Icon from '../components/Icon'

function formatTrackArtist(track) {
  return track?.artist || track?.user?.username || 'Unknown artist'
}

function TrackTile({ track, active, index, onPlay, onToggleLike }) {
  const cover = track?.cover ? fullUrl(track.cover) : null
  return (
    <article className={`spotify-track ${active ? 'active' : ''}`}>
      <button type="button" className="spotify-track-main" onClick={() => onPlay(track)} aria-label={`Play ${track.title || 'track'}`}>
        <div className="spotify-track-index">{active ? '▶' : index + 1}</div>
        <div className="spotify-track-cover">{cover ? <img src={cover} alt="" /> : <div>♪</div>}</div>
        <div className="spotify-track-meta">
          <strong>{track.title || 'Untitled'}</strong>
          <span>{formatTrackArtist(track)}</span>
        </div>
      </button>
      <button
        type="button"
        className={`spotify-track-like ${track.liked ? 'active' : ''}`}
        onClick={() => onToggleLike(track)}
        aria-label={track.liked ? `Remove ${track.title || 'track'} from liked songs` : `Add ${track.title || 'track'} to liked songs`}
      >
        <Icon name={track.liked ? 'heartFill' : 'heart'} size={16} />
      </button>
    </article>
  )
}

export default function Music() {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [query, setQuery] = useState('')
  const { tracks, setTracks, currentTrack, currentTrackId, playTrack, isPlaying, togglePlay, nextTrack, prevTrack, volume, muted, setPlayerVolume, repeat, setRepeat, formatTime, currentTime, duration, seekRatio } = useMusicPlayer()

  useEffect(() => {
    let alive = true

    const load = async () => {
      setLoading(true)
      setError('')
      try {
        const data = await fetchMusic()
        if (!alive) return
        setTracks(Array.isArray(data) ? data : [])
      } catch {
        if (alive) setError('Could not load your music library right now.')
      } finally {
        if (alive) setLoading(false)
      }
    }

    load()
    const refresh = () => load()
    window.addEventListener('connect-content-updated', refresh)
    return () => {
      alive = false
      window.removeEventListener('connect-content-updated', refresh)
    }
  }, [setTracks])

  const filteredTracks = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return tracks
    return tracks.filter((track) => `${track.title || ''} ${formatTrackArtist(track)}`.toLowerCase().includes(q))
  }, [tracks, query])

  const likedTracks = useMemo(() => tracks.filter((track) => track.liked), [tracks])

  const selected = currentTrack || filteredTracks[0] || tracks[0] || null
  const currentLabel = useMemo(() => {
    if (!currentTrack) return 'Nothing playing'
    return currentTrack.title || 'Untitled track'
  }, [currentTrack])

  const pct = duration ? Math.min(100, (currentTime / duration) * 100) : 0

  const handleToggleLike = async (track) => {
    try {
      await toggleTrackLike(track.id)
    } catch (error) {
      console.error(error)
    }
  }

  return (
    <div className="page-shell music-page page-fade-in spotify-shell">
      <section className="music-hero surface spotify-hero">
        <div className="music-hero-copy">
          <div className="eyebrow"><Icon name="music" size={16} /> Your Library</div>
          <h1>Music</h1>
          <p>A full player layout with library browsing, playback controls, queue context, liked songs, and a calmer Spotify-style structure.</p>
        </div>
        <div className="music-hero-card spotify-hero-card">
          <span>Library</span>
          <strong>{tracks.length}</strong>
          <small>{currentTrack ? currentLabel : 'No track selected'}</small>
        </div>
      </section>

      <div className="spotify-layout">
        <aside className="surface spotify-sidebar">
          <div className="spotify-sidebar-head">
            <div>
              <div className="eyebrow">Collection</div>
              <strong>Browse</strong>
            </div>
            <button type="button" className={`mini-chip btn-animated ${repeat !== 'off' ? 'active' : ''}`} onClick={() => setRepeat(repeat === 'off' ? 'all' : repeat === 'all' ? 'one' : 'off')}>
              {repeat === 'one' ? 'Repeat 1' : repeat === 'all' ? 'Repeat all' : 'Repeat off'}
            </button>
          </div>

          <label className="spotify-search" aria-label="Search music">
            <Icon name="search" size={16} />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search songs, artists" />
          </label>

          <div className="spotify-section">
            <div className="spotify-section-head">
              <strong>All songs</strong>
              <span className="mini-chip">{filteredTracks.length}</span>
            </div>
            <div className="spotify-library-list" aria-busy={loading} aria-live="polite">
              {loading && <div className="empty-state">Loading tracks…</div>}
              {!loading && error && <div className="empty-state">{error}</div>}
              {!loading && !error && filteredTracks.length === 0 && <div className="empty-state">No tracks match that search.</div>}
              {filteredTracks.map((track, index) => (
                <TrackTile
                  key={track.id}
                  track={track}
                  index={index}
                  active={currentTrackId === track.id}
                  onPlay={playTrack}
                  onToggleLike={handleToggleLike}
                />
              ))}
            </div>
          </div>

          <div className="spotify-section spotify-liked-section">
            <div className="spotify-section-head">
              <strong>Liked songs</strong>
              <span className="mini-chip">{likedTracks.length}</span>
            </div>
            <div className="spotify-liked-list">
              {likedTracks.length === 0 && <div className="empty-state compact-empty">Like songs to save them here.</div>}
              {likedTracks.map((track, index) => (
                <TrackTile
                  key={`liked-${track.id}`}
                  track={track}
                  index={index}
                  active={currentTrackId === track.id}
                  onPlay={playTrack}
                  onToggleLike={handleToggleLike}
                />
              ))}
            </div>
          </div>
        </aside>

        <section className="surface spotify-now-playing spotify-player-main">
          <div className="spotify-now-header">
            <div className="eyebrow">Now playing</div>
            <span className="mini-chip">{isPlaying ? 'Playing' : 'Paused'}</span>
          </div>
          <div className="music-now-art spotify-now-art">
            {selected?.cover ? <img src={fullUrl(selected.cover)} alt="" /> : <div className="cover-placeholder">♪</div>}
          </div>
          <div className="music-now-copy">
            <h2>{selected?.title || 'Choose a track'}</h2>
            <p>{selected ? `by ${formatTrackArtist(selected)}` : 'Select a song from the list to start playback.'}</p>
            {selected && (
              <button type="button" className={`btn btn-chip btn-animated music-like-chip ${selected.liked ? 'active' : ''}`} onClick={() => handleToggleLike(selected)}>
                <Icon name={selected.liked ? 'heartFill' : 'heart'} size={16} />
                <span>{selected.liked ? 'Liked' : 'Like song'}</span>
              </button>
            )}
          </div>

          <div className="spotify-transport">
            <button type="button" className="btn btn-ghost btn-animated" onClick={prevTrack}>Previous</button>
            <button type="button" className="btn btn-primary btn-animated" onClick={togglePlay} disabled={!currentTrack}>{isPlaying ? 'Pause' : 'Play'}</button>
            <button type="button" className="btn btn-ghost btn-animated" onClick={nextTrack}>Next</button>
          </div>

          <div className="spotify-seek">
            <span>{formatTime(currentTime)}</span>
            <button type="button" className="timeline-track" onClick={(e) => { const rect = e.currentTarget.getBoundingClientRect(); const ratio = (e.clientX - rect.left) / rect.width; seekRatio(ratio) }} aria-label="Seek track">
              <span style={{ width: `${pct}%` }} />
            </button>
            <span>{formatTime(duration)}</span>
          </div>

          <div className="spotify-controls-row">
            <div className="spotify-volume-block">
              <Icon name={muted || volume === 0 ? 'volumeMute' : 'volume'} size={16} />
              <input className="volume-slider" type="range" min="0" max="1" step="0.01" value={muted ? 0 : volume} onChange={(e) => setPlayerVolume(e.target.value)} aria-label="Volume" />
            </div>
            <button type="button" className="mini-chip btn-animated" onClick={() => setRepeat(repeat === 'off' ? 'all' : repeat === 'all' ? 'one' : 'off')}>
              {repeat === 'one' ? '1' : '↻'}
            </button>
          </div>
        </section>

        <aside className="surface spotify-queue">
          <div className="spotify-sidebar-head">
            <div>
              <div className="eyebrow">Up next</div>
              <strong>Queue</strong>
            </div>
            <span className="mini-chip">{filteredTracks.length} tracks</span>
          </div>
          <div className="spotify-queue-list">
            {filteredTracks.slice(0, 8).map((track, index) => (
              <button key={`${track.id}-queue`} type="button" className={`spotify-queue-item ${currentTrackId === track.id ? 'active' : ''}`} onClick={() => playTrack(track)}>
                <span>{index + 1}</span>
                <div>
                  <strong>{track.title || 'Untitled'}</strong>
                  <small>{formatTrackArtist(track)}</small>
                </div>
              </button>
            ))}
          </div>
        </aside>
      </div>
    </div>
  )
}
